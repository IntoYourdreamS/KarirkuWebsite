<?php

  // --- 1. SETUP KONEKSI KE SUPABASE ---

  require __DIR__ . '/../../vendor/autoload.php';

  use GuzzleHttp\Client;



  $supabaseUrl = 'https://tkjnbelcgfwpbhppsnrl.supabase.co';

  $supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRram5iZWxjZ2Z3cGJocHBzbnJsIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MTc0MDc2MiwiZXhwIjoyMDc3MzE2NzYyfQ.vZoNXxMWtoG4ktg7K6Whqv8EFzCv7qbS3OAHEfxVoR0';



  $daftar_perusahaan = [];

  $keyword = isset($_GET['q']) ? $_GET['q'] : '';



  try {

      $client = new Client([

          'base_uri' => $supabaseUrl . '/rest/v1/',

          'headers' => [

              'apikey'        => $supabaseKey,

              'Authorization' => 'Bearer ' . $supabaseKey,

              'Content-Type'  => 'application/json',

          ],

          'http_errors' => false

      ]);



      $queryUrl = 'perusahaan?select=*,lowongan(count)&order=id_perusahaan.desc';



      if (!empty($keyword)) {

          $queryUrl .= '&nama_perusahaan=ilike.*' . urlencode($keyword) . '*';

      }



      $response = $client->get($queryUrl);

      if ($response->getStatusCode() == 200) {

          $daftar_perusahaan = json_decode($response->getBody(), true);

      }

  } catch (Exception $e) {}



  $activePage = 'perusahaan';

  include 'header.php';

  include 'sidebar.php';

  include 'topbar.php';

?>



<style>

  /* --- LAYOUT --- */

  .main-content { background-color: #F7F8FC; padding: 24px; min-height: 100vh; }

  h2.mb-4 { display: none; }



  /* --- SEARCH & FILTER BAR --- */

  .top-action-bar { display: flex; gap: 16px; margin-bottom: 24px; }

 

  .search-form-box {

    background-color: #FFFFFF; border-radius: 12px; border: 1px solid #EFEFEF;

    padding: 0 16px; height: 50px; display: flex; align-items: center;

    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02); flex-grow: 1;

  }

  .search-input {

    border: none; outline: none; flex-grow: 1; font-size: 15px; color: #333;

    height: 100%; background: transparent;

  }

  .search-submit-btn {

    background: none; border: none; cursor: pointer; padding: 0;

    display: flex; align-items: center; justify-content: center; height: 100%;

  }

  .search-submit-btn svg { fill: #7B61FF; width: 20px; height: 20px; }



  .filter-box {

    background-color: #FFFFFF; border-radius: 12px; border: 1px solid #EFEFEF;

    padding: 0 20px; height: 50px; display: flex; align-items: center;

    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02); white-space: nowrap;

    font-weight: 600; color: #555; font-size: 14px;

  }

  .filter-count {

    background-color: #7B61FF; color: white; border-radius: 6px;

    padding: 2px 8px; font-size: 12px; font-weight: bold; margin-left: 8px;

  }



  /* --- LIST KIRI --- */

  .company-card-list { display: flex; flex-direction: column; gap: 12px; }

 

  .company-card {

    background-color: #FFFFFF; border-radius: 12px; border: 1px solid #EFEFEF;

    padding: 18px 24px; display: flex; align-items: center; justify-content: space-between;

    cursor: pointer; transition: all 0.2s ease;

    box-shadow: 0 2px 4px rgba(0,0,0,0.02);

  }

 

  /* Efek Hover & Active */

  .company-card:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.05); border-color: #dce0ff; }

  .company-card.active { border: 2px solid #5967FF; background-color: #F4F5FF; }



  .card-left { display: flex; flex-direction: column; }

  .company-name { font-weight: 700; font-size: 15px; color: #2D3748; margin-bottom: 4px; }

  .job-count { font-size: 13px; color: #718096; }

 

  /* Wrapper Kanan (Status + Tombol Detail) */

  .card-right { display: flex; align-items: center; gap: 10px; }



  /* Badge Status */

  .status-badge {

    background-color: #E6F6EC; color: #38A169;

    font-weight: 600; padding: 6px 12px; border-radius: 6px; font-size: 13px;

    display: flex; align-items: center; gap: 6px;

  }



  /* TOMBOL DETAIL (DIKEMBALIKAN) */

  .btn-detail-mini {

    padding: 6px 14px;

    background-color: #5967FF; color: white;

    text-decoration: none; font-size: 13px; font-weight: 600;

    border-radius: 6px; transition: 0.2s;

  }

  .btn-detail-mini:hover { background-color: #4754E5; color: white; }



  /* --- PREVIEW KANAN --- */

  .preview-panel-wrapper { position: sticky; top: 100px; height: fit-content; }



  .preview-card {

      background: white; border-radius: 16px;

      border: 1px solid #EFEFEF;

      box-shadow: 0 10px 30px rgba(0,0,0,0.05);

      padding: 25px; text-align: center; min-height: 350px;

      display: flex; flex-direction: column; align-items: center;

  }



  .empty-state {

      display: flex; flex-direction: column; align-items: center; justify-content: center;

      height: 100%; color: #A0AEC0; margin-top: 60px;

  }

  .empty-icon { font-size: 40px; margin-bottom: 15px; color: #CBD5E0; }



  #previewContent { width: 100%; display: none; }

 

  .preview-header {

      width: 100%; border-bottom: 1px solid #F1F1F1;

      padding-bottom: 15px; margin-bottom: 15px;

  }

  .preview-logo-box {

      width: 70px; height: 70px; border-radius: 12px;

      background-color: #F7F9FC; border: 1px solid #E2E8F0;

      display: flex; align-items: center; justify-content: center;

      font-size: 28px; font-weight: 800; color: #5967FF;

      margin: 0 auto 15px auto; overflow: hidden;

  }

  .preview-img { width: 100%; height: 100%; object-fit: cover; }



  .preview-title { font-size: 18px; font-weight: 800; color: #2D3748; margin-bottom: 5px; }

  .preview-subtitle { font-size: 13px; color: #718096; }

  .preview-body { text-align: left; font-size: 13px; color: #4A5568; line-height: 1.6; margin-bottom: 20px; }

  .preview-label { font-weight: 700; color: #2D3748; display: block; margin-bottom: 4px; margin-top: 12px; }



  .btn-full-detail {

      display: block; width: 100%; padding: 10px;

      background-color: #5967FF; color: white;

      text-decoration: none; font-weight: 600; border-radius: 8px;

      transition: 0.2s; margin-top: auto; font-size: 14px;

  }

  .btn-full-detail:hover { background-color: #4754E5; color: white; }



</style>



<div class="main-content">

 

  <div class="top-action-bar">

      <form action="" method="GET" class="search-form-box">

          <input type="text" name="q" class="search-input" placeholder="Cari perusahaan..." value="<?php echo htmlspecialchars($keyword); ?>" autocomplete="off">

          <button type="submit" class="search-submit-btn"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0s208 93.1 208 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"/></svg></button>

      </form>

      <div class="filter-box">

          Total Data <span class="filter-count"><?php echo count($daftar_perusahaan); ?></span>

      </div>

  </div>



  <div class="container-fluid p-0">

    <div class="row">

     

      <div class="col-lg-8">

        <div class="company-card-list">

            <?php

            if (empty($daftar_perusahaan)) {

                echo "<div style='text-align:center; padding:40px; color:#888;'>Tidak ada data.</div>";

            } else {

                foreach ($daftar_perusahaan as $index => $row) {

                  $nama_pt = $row['nama_perusahaan'] ?? 'Tanpa Nama';

                  $id_pt   = $row['id_perusahaan'];

                  $jml_loker = isset($row['lowongan'][0]['count']) ? $row['lowongan'][0]['count'] : 0;

                  $logo = $row['logo'] ?? '';

                  $deskripsi = substr($row['deskripsi'] ?? 'Belum ada deskripsi.', 0, 120) . '...';



                  $dataJSON = htmlspecialchars(json_encode([

                      'id' => $id_pt,

                      'nama' => $nama_pt,

                      'loker' => $jml_loker,

                      'desc' => $deskripsi,

                      'logo' => $logo,

                      'alamat' => $row['alamat'] ?? '-'

                  ]), ENT_QUOTES, 'UTF-8');

            ?>



            <div class="company-card" onclick="showPreview(this, <?php echo $dataJSON; ?>)">

              <div class="card-left">

                  <span class="company-name"><?php echo htmlspecialchars($nama_pt); ?></span>

                  <span class="job-count"><?php echo $jml_loker; ?> Lowongan Aktif</span>

              </div>

             

              <div class="card-right">

                  <span class="status-badge">Aktif <i class="fas fa-check-circle"></i></span>

                 

                  <a href="detail_perusahaan.php?id=<?php echo $id_pt; ?>"

                     class="btn-detail-mini"

                     onclick="event.stopPropagation()">Detail</a>

              </div>

            </div>



            <?php } } ?>

        </div>

      </div>



      <div class="col-lg-4">

          <div class="preview-panel-wrapper">

              <div class="preview-card">

                 

                  <div id="emptyState" class="empty-state">

                      <i class="far fa-building empty-icon"></i>

                      <p style="font-size:14px;">Klik perusahaan untuk<br>melihat ringkasan.</p>

                  </div>



                  <div id="previewContent">

                      <div class="preview-header">

                          <div class="preview-logo-box" id="pLogo"></div>

                          <div class="preview-title" id="pName">Nama PT</div>

                          <div class="preview-subtitle" id="pLoker">0 Lowongan</div>

                      </div>



                      <div class="preview-body">

                          <span class="preview-label">Deskripsi</span>

                          <p id="pDesc">...</p>

                          <span class="preview-label">Lokasi</span>

                          <p id="pAddr">...</p>

                      </div>



                      <a href="#" id="btnFullDetail" class="btn-full-detail">Lihat Detail Lengkap</a>

                  </div>



              </div>

          </div>

      </div>



    </div>

  </div>

</div>



<script>

function showPreview(cardElement, data) {

    // Style Aktif Card

    document.querySelectorAll('.company-card').forEach(c => c.classList.remove('active'));

    cardElement.classList.add('active');



    // Tampilkan Preview

    document.getElementById('emptyState').style.display = 'none';

    document.getElementById('previewContent').style.display = 'block';



    // Isi Data

    document.getElementById('pName').innerText = data.nama;

    document.getElementById('pLoker').innerText = data.loker + " Lowongan";

    document.getElementById('pDesc').innerText = data.desc;

    document.getElementById('pAddr').innerText = data.alamat;

   

    // Handle Logo

    const logoBox = document.getElementById('pLogo');

    if (data.logo && data.logo.trim() !== '') {

        logoBox.innerHTML = `<img src="${data.logo}" class="preview-img">`;

    } else {

        logoBox.innerHTML = data.nama.charAt(0).toUpperCase();

    }



    // Update Link Tombol Bawah Preview

    document.getElementById('btnFullDetail').href = 'detail_perusahaan.php?id=' + data.id;

}

</script>



<?php include 'footer.php'; ?>


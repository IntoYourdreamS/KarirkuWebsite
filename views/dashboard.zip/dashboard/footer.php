<footer class="text-center py-3 mt-4 text-muted small">
  © 2025 KarirKu Admin. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

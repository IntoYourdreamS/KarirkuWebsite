<?php
// Pastikan variabel didefinisikan secara default jika belum disetel
$activePage = $activePage ?? ''; 
$count_pending_perusahaan = $count_pending_perusahaan ?? 0; // Tetap ada, tapi tidak ditampilkan

// Tentukan apakah menu Laporan (parent) harus aktif/terbuka (jika sub-menu 'laporan_lain' aktif)
$parentActive = (in_array($activePage, ['laporan_umum'])); // Asumsi nama halaman sub-menu Laporan
?>

<div class="sidebar" aria-label="Karirku. Admin">
    
    <a href="index.php" class="nav-item <?= ($activePage == 'halaman utama') ? 'active' : '' ?>">
        <i class="lucide-layout-dashboard"></i>
        <span>Halaman utama</span>
    </a>

    <a href="lowongan.php" class="nav-item <?= ($activePage == 'lowongan') ? 'active' : '' ?>">
        <i class="lucide-users"></i>
        <span>Lowongan</span>
    </a>

    <a href="perusahaan.php" class="nav-item <?= ($activePage == 'perusahaan') ? 'active' : '' ?>">
        <i class="lucide-building"></i> 
        <span>Perusahaan</span>
    </a>

    <a href="#" class="nav-item has-submenu <?= ($parentActive) ? 'active' : '' ?>" id="menuLaporan">
        <i class="lucide-bar-chart-2"></i>
        <span>Laporan</span>
    </a>
    
    <div class="submenu <?= ($parentActive) ? 'show' : '' ?>">
        <a href="#" class="nav-item submenu-item <?= ($activePage == 'laporan_umum') ? 'active' : '' ?>">
            <span>Laporan Umum</span>
        </a>
    </div>
</div>

<style>
.sidebar .nav-item {
    display: flex;
    align-items: center;
    position: relative;
    padding: 10px 15px;
    text-decoration: none;
    color: #333;
    transition: background-color 0.2s;
}

/* Efek Aktif (Biru/Highlight) */
.sidebar .nav-item.active {
    background-color: #e8eaff;
    color: #5967FF;
    font-weight: 600;
    border-left: 3px solid #5967FF;
}

/* Style untuk Submenu Container */
.submenu {
    overflow: hidden;
    max-height: 0; 
    transition: max-height 0.3s ease-out;
    background-color: #f7f7f7;
}

.submenu.show {
    max-height: 200px;
}

/* Style untuk Item di Submenu */
.submenu-item {
    padding: 10px 10px 10px 45px !important; 
    font-size: 0.95em;
    display: flex;
    align-items: center;
    border-left: 3px solid transparent;
}

.submenu-item.active {
    border-left: 3px solid #5967FF; 
    background-color: #e8eaff;
}
/* Badge styling tetap ada, namun saat ini tidak digunakan */
.badge {
    padding: 3px 6px;
    font-size: 0.75em;
    font-weight: bold;
    line-height: 1;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    border-radius: 0.25rem;
    color: white;
    background-color: #dc3545;
    margin-left: auto;
}
</style>

<script>
// JS UNTUK TOGGLE SUBMENU
document.addEventListener('DOMContentLoaded', function() {
    const menuLaporan = document.getElementById('menuLaporan');
    const submenu = menuLaporan ? menuLaporan.nextElementSibling : null;

    if (menuLaporan && submenu) {
        // Tentukan tinggi awal jika menu sudah aktif/terbuka
        if (submenu.classList.contains('show')) {
            submenu.style.maxHeight = submenu.scrollHeight + "px";
        }
        
        menuLaporan.addEventListener('click', function(e) {
            e.preventDefault(); 
            
            if (submenu.classList.contains('show')) {
                // Tutup
                submenu.style.maxHeight = '0';
                submenu.classList.remove('show');
            } else {
                // Buka
                submenu.classList.add('show');
                submenu.style.maxHeight = submenu.scrollHeight + "px";
            }
        });
    }
});
</script>
<?php 
  // --- 1. KONEKSI DATABASE & LOGIC ---
  require __DIR__ . '/../../vendor/autoload.php';
  use GuzzleHttp\Client;

  // Konfigurasi
  $supabaseUrl = 'https://tkjnbelcgfwpbhppsnrl.supabase.co';
  $supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRram5iZWxjZ2Z3cGJocHBzbnJsIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MTc0MDc2MiwiZXhwIjoyMDc3MzE2NzYyfQ.vZoNXxMWtoG4ktg7K6Whqv8EFsCv7qbS3OAHEfxVoR0';

  $id_perusahaan = isset($_GET['id']) ? $_GET['id'] : 0;
  $data = null;

  try {
      $client = new Client([
          'base_uri' => $supabaseUrl . '/rest/v1/',
          'headers' => [
              'apikey' => $supabaseKey, 'Authorization' => 'Bearer ' . $supabaseKey,
          ],
          'http_errors' => false
      ]);

      $response = $client->get('perusahaan?id_perusahaan=eq.' . $id_perusahaan . '&select=*');
      if ($response->getStatusCode() == 200) {
          $result = json_decode($response->getBody(), true);
          if (!empty($result)) { $data = $result[0]; }
      }
  } catch (Exception $e) { }

  // Data Handling
  if (!$data) {
      $nama_pt = "PT Contoh Sejahtera";
      $deskripsi = "Data tidak ditemukan.";
      $alamat = "-";
      $website = "#";
      $logo_url = ""; 
      $rating = "0.0";
      $makna_logo = "-"; $visi_misi = "-"; $struktur = "-"; $kebijakan = "-"; $anak_perusahaan = "-";
  } else {
      $nama_pt = $data['nama_perusahaan'] ?? 'Tanpa Nama';
      $website = $data['website'] ?? '#';
      $logo_url = $data['logo'] ?? ''; 
      $rating = $data['rating'] ?? '4.5';
      $deskripsi = $data['deskripsi'] ?? 'Belum ada deskripsi.';
      $alamat = $data['alamat'] ?? '-';
      $makna_logo = $data['makna_logo'] ?? '-';
      $visi_misi = $data['visi_misi'] ?? '-';
      $struktur = $data['struktur_organisasi'] ?? '-';
      $kebijakan = $data['kebijakan_sm'] ?? '-';
      $anak_perusahaan = $data['anak_perusahaan'] ?? '-';
  }

  include 'header.php';
  include 'topbar.php';
?>

<style>
  /* --- 1. RESET TOTAL LAYOUT (WAJIB AGAR NEMPEL) --- */
  body {
      margin: 0; padding: 0;
      background-color: #F7F8FC;
  }

  /* Hilangkan Sidebar */
  .sidebar, .left-sidebar { display: none !important; }
  
  /* Main Content di-Reset Total */
  .main-content { 
      padding: 0 !important;       /* Hapus padding bawaan */
      margin: 0 !important;        /* Hapus margin bawaan */
      width: 100% !important; 
      max-width: 100% !important;
      margin-top: 70px !important; /* Pas 70px sesuai tinggi Topbar */
      min-height: 100vh;
      overflow-x: hidden;          /* Hilangkan scroll samping */
  }

  /* --- 2. BANNER HEADER (FULL WIDTH) --- */
  .company-banner {
      width: 100vw;      /* Lebar viewport penuh */
      height: 350px;     /* Tinggi banner */
      margin-left: calc(-50vw + 50%); /* Trik CSS biar mentok kiri kanan */
      
      /* GAMBAR BACKGROUND */
      background-image: url('../../assets/img/background.png'); 
      background-size: cover;            /* Memenuhi area tanpa gepeng */
      background-position: center center; /* Fokus tengah gambar */
      background-repeat: no-repeat;
      
      position: relative;
      display: block;
  }

  /* Overlay Gelap Halus */
  .company-banner::after {
      content: '';
      position: absolute; top: 0; left: 0; right: 0; bottom: 0;
      background: linear-gradient(to bottom, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.5) 100%);
  }

  /* --- 3. CONTAINER KONTEN (MENUMPUK KE ATAS) --- */
  .content-wrapper {
      max-width: 1140px;
      margin: 0 auto; /* Tengah */
      padding: 0 20px;
      position: relative;
      z-index: 10;
      /* Margin negatif untuk menarik konten ke atas banner */
      margin-top: -100px; 
      padding-bottom: 60px;
  }

  /* --- 4. TOMBOL KEMBALI (FLOATING) --- */
  .btn-back-floating {
      position: absolute;
      top: -200px; /* Naik di dalam banner */
      left: 20px;
      z-index: 20;
      color: white;
      text-decoration: none;
      font-weight: 600;
      font-size: 15px;
      text-shadow: 0 2px 4px rgba(0,0,0,0.6);
      display: flex; align-items: center; gap: 8px;
  }
  .btn-back-floating:hover { color: #ddd; }

  /* --- 5. KARTU HEADER PUTIH --- */
  .header-card {
      background: white;
      border-radius: 16px;
      padding: 30px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.08);
      display: flex;
      align-items: flex-end;
      gap: 25px;
      margin-bottom: 25px;
      position: relative;
  }

  .logo-frame {
      width: 130px; height: 130px;
      background: white;
      border-radius: 16px;
      padding: 5px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      flex-shrink: 0;
      /* Posisi Logo keluar ke atas */
      position: relative;
      top: -50px; 
      margin-bottom: -50px;
  }

  .logo-content {
      width: 100%; height: 100%;
      border-radius: 12px;
      background-color: #fff;
      display: flex; align-items: center; justify-content: center;
      overflow: hidden;
      border: 1px solid #f0f0f0;
  }
  .logo-img { width: 100%; height: 100%; object-fit: cover; }
  .logo-initial { font-size: 48px; font-weight: 800; color: #5967FF; }

  .header-details { flex: 1; padding-bottom: 5px; }
  .header-details h1 { margin: 0; font-size: 28px; font-weight: 800; color: #2D3748; }
  .header-details p { margin: 5px 0 0; color: #718096; font-size: 15px; font-weight: 500; }

  /* --- 6. KONTEN CARD (PUTIH) --- */
  .card-white {
      background: white; border-radius: 16px; padding: 0 30px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.03);
      border: 1px solid #F0F0F0;
  }

  /* Accordion */
  .acc-item { border-bottom: 1px solid #F1F1F1; }
  .acc-item:last-child { border-bottom: none; }
  .acc-head { 
      padding: 20px 0; cursor: pointer; display: flex; 
      justify-content: space-between; align-items: center; 
      font-weight: 700; color: #2D3748; font-size: 16px;
  }
  .acc-head:hover { color: #5967FF; }
  .acc-icon { width: 16px; transition: 0.3s; fill: #A0AEC0; }
  .acc-head.active .acc-icon { transform: rotate(180deg); fill: #5967FF; }
  .acc-body { max-height: 0; overflow: hidden; transition: 0.4s; color: #555; line-height: 1.6; }
  .acc-body.open { max-height: 1000px; padding-bottom: 20px; }

  /* Sidebar Kanan */
  .sidebar-box {
      background: white; border-radius: 16px; padding: 25px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.03);
      border: 1px solid #F0F0F0;
      position: sticky; top: 90px;
  }
  .check-item { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #eee; font-size: 14px; color: #555; font-weight: 500; }
  .icon-green { color: #38A169; }
  
  .rating-section { margin-top: 25px; margin-bottom: 5px; }
  .rating-num { font-size: 18px; font-weight: 700; color: #2D3748; display: flex; gap: 6px; align-items: center; }

  /* Tombol */
  .btn-delete-sidebar { 
      width: 100%; background-color: #FFF5F5; color: #E53E3E; border: 1px solid #FED7D7;
      padding: 12px; border-radius: 10px; font-weight: 600; margin-top: 20px; 
      cursor: pointer; display: flex; justify-content: center; align-items: center; gap: 8px; 
      text-decoration: none; transition: 0.2s; 
  }
  .btn-delete-sidebar:hover { background-color: #E53E3E; color: white; border-color: #E53E3E; }

  .btn-visit { 
      display: inline-flex; padding: 10px 20px; background: #5967FF; color: white; 
      border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 14px;
      align-items: center; gap: 8px; transition: 0.2s; margin-bottom: 5px;
  }
  .btn-visit:hover { background: #4754d1; color: white; }

</style>

<div class="main-content">
    
    <div class="company-banner">
        <div class="content-wrapper" style="height: 100%; margin-top: 0; padding-bottom: 0;">
             <a href="perusahaan.php" class="btn-back-floating">
                <i class="fas fa-arrow-left"></i> Kembali ke Daftar
            </a>
        </div>
    </div>

    <div class="content-wrapper">
        
        <div class="header-card">
            <div class="logo-frame">
                <div class="logo-content">
                    <?php if (!empty($logo_url)): ?>
                        <img src="<?php echo htmlspecialchars($logo_url); ?>" class="logo-img">
                    <?php else: ?>
                        <span class="logo-initial"><?php echo strtoupper(substr($nama_pt, 0, 1)); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="header-details">
                <h1><?php echo htmlspecialchars($nama_pt); ?></h1>
                <p>ID: <?php echo $id_perusahaan; ?> &bull; Mitra Terverifikasi</p>
            </div>
            
            <?php if ($website != '#'): ?>
                <a href="<?php echo $website; ?>" target="_blank" class="btn-visit">
                    <i class="fas fa-globe"></i> Kunjungi Website
                </a>
            <?php endif; ?>
        </div>

        <div class="row">
            <div class="col-lg-8">
                <div class="card-white">
                    
                    <div class="acc-item">
                        <div class="acc-head" onclick="toggleAcc('desc', this)">
                            Deskripsi Perusahaan
                            <svg class="acc-icon" viewBox="0 0 512 512"><path d="M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z"/></svg>
                        </div>
                        <div id="desc" class="acc-body">
                            <?php echo nl2br(htmlspecialchars($deskripsi)); ?>
                        </div>
                    </div>

                    <div class="acc-item">
                        <div class="acc-head" onclick="toggleAcc('addr', this)">
                            Alamat
                            <svg class="acc-icon" viewBox="0 0 512 512"><path d="M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z"/></svg>
                        </div>
                        <div id="addr" class="acc-body"><?php echo nl2br(htmlspecialchars($alamat)); ?></div>
                    </div>

                    <div class="acc-item">
                        <div class="acc-head" onclick="toggleAcc('makna', this)">
                            Makna Logo
                            <svg class="acc-icon" viewBox="0 0 512 512"><path d="M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z"/></svg>
                        </div>
                        <div id="makna" class="acc-body"><?php echo nl2br(htmlspecialchars($makna_logo)); ?></div>
                    </div>

                    <div class="acc-item">
                        <div class="acc-head" onclick="toggleAcc('visi', this)">
                            Visi & Misi
                            <svg class="acc-icon" viewBox="0 0 512 512"><path d="M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z"/></svg>
                        </div>
                        <div id="visi" class="acc-body"><?php echo nl2br(htmlspecialchars($visi_misi)); ?></div>
                    </div>

                    <div class="acc-item">
                        <div class="acc-head" onclick="toggleAcc('struk', this)">
                            Struktur Organisasi
                            <svg class="acc-icon" viewBox="0 0 512 512"><path d="M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z"/></svg>
                        </div>
                        <div id="struk" class="acc-body"><?php echo nl2br(htmlspecialchars($struktur)); ?></div>
                    </div>

                    <div class="acc-item">
                        <div class="acc-head" onclick="toggleAcc('keb', this)">
                            Kebijakan SM Terintegrasi
                            <svg class="acc-icon" viewBox="0 0 512 512"><path d="M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z"/></svg>
                        </div>
                        <div id="keb" class="acc-body"><?php echo nl2br(htmlspecialchars($kebijakan)); ?></div>
                    </div>

                    <div class="acc-item">
                        <div class="acc-head" onclick="toggleAcc('anak', this)">
                            Anak Perusahaan
                            <svg class="acc-icon" viewBox="0 0 512 512"><path d="M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z"/></svg>
                        </div>
                        <div id="anak" class="acc-body"><?php echo nl2br(htmlspecialchars($anak_perusahaan)); ?></div>
                    </div>

                </div>
            </div>

            <div class="col-lg-4">
                <div class="sidebar-box">
                    <div style="font-weight:700; margin-bottom:15px;">Status</div>
                    <div class="check-item">Info Lengkap <i class="fas fa-check-circle icon-green"></i></div>
                    <div class="check-item">Terpercaya <i class="fas fa-check-circle icon-green"></i></div>
                    
                    <div class="rating-section">
                        <div style="font-weight:700; font-size:16px;">Rating</div>
                        <div class="rating-num"><?php echo htmlspecialchars($rating); ?> <i class="fas fa-star" style="color: #FFC107;"></i></div>
                    </div>

                    <a href="hapus_perusahaan.php?id=<?php echo $id_perusahaan; ?>" 
                       class="btn-delete-sidebar"
                       onclick="return confirm('⚠️ PERINGATAN!\n\nYakin ingin menghapus data <?php echo $nama_pt; ?>?');">
                        <i class="fas fa-trash-alt"></i> Hapus Perusahaan
                    </a>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
function toggleAcc(id, el) {
    document.getElementById(id).classList.toggle('open');
    el.classList.toggle('active');
}
</script>

<?php include 'footer.php'; ?>